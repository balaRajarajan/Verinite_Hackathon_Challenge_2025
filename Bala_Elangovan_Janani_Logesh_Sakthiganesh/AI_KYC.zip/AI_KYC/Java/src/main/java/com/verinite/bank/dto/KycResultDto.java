package com.verinite.bank.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class KycResultDto {

    private Long id;

    @JsonProperty("aadhaar_number")
    private String aadhaarNumber;

    private String name;
    private String dob;
    private String gender;

    @JsonProperty("ocr_confidence_score")
    private Double ocrConfidenceScore;

    @JsonProperty("is_blurry")
    private Boolean isBlurry;

    @JsonProperty("blur_score")
    private Double blurScore;
}
