const BASE_URL = "http://localhost:8999/api/bank";

export const submitApplication = async (formData) => {
  const response = await fetch(`${BASE_URL}/submit`, {
    method: "POST",
    body: formData,
  });

  if (!response.ok) {
    throw new Error("Failed to submit application");
  }

  return await response.json();

  
};


// ===============================
// STEP 2 - ID Verification
// ===============================
export const verifyId = async (applicationId) => {
  try {
    const response = await fetch(
      `${BASE_URL}/id-verification/${applicationId}`,
      {
        method: "POST",
      }
    );

    if (!response.ok) {
      throw new Error("ID Verification failed");
    }

    return await response.text(); // because backend returns string
  } catch (error) {
    console.error("ID Verification Error:", error);
    throw error;
  }
};

export const getApplicationStatus = async (id) => {
  const response = await fetch(
    `http://localhost:8999/api/bank/status/${id}`
  );

  if (!response.ok) throw new Error("Failed");

  return await response.text();
};

export const startKyc = async (applicationId) => {
  const response = await fetch(
    `http://localhost:8999/api/bank/kyc/start/${applicationId}`,
    {
      method: "POST",
    }
  );

  if (!response.ok) {
    throw new Error("Failed to start KYC");
  }

  return await response.json();
};

