# ===============================
# Agentic All-in-One with Streamlit UI
# FINAL – LIGHT BACKGROUND, HORIZONTAL GRAPHS, KPI SUMMARY, CSV & JMX
# ===============================

import os, threading, shutil, time, json
from time import sleep, strftime
import pandas as pd
import matplotlib.pyplot as plt
import requests
from flask import Flask, jsonify
import streamlit as st

# -----------------------------
st.set_page_config(
    page_title="Agentic Test Automation UI",
    layout="wide",
    page_icon="🚀"
)

# ---------- Light Theme Custom CSS ----------
st.markdown("""
<style>
.stApp { background: linear-gradient(135deg,#f8fbff 0%,#eef4ff 50%,#e6f0ff 100%); color:#1f2937;}
.block-container {padding: 2rem;}
h1 {color:#0f172a; font-weight:700;}
h2,h3 {color:#1e40af;}
.card {background:#fff; padding:20px; border-radius:14px; box-shadow:0 8px 24px rgba(0,0,0,0.08); margin-bottom:25px; border-left:6px solid #3b82f6;}
.stButton > button {background:linear-gradient(90deg,#2563eb,#3b82f6); color:white; font-weight:600; border-radius:8px; padding:8px 20px; border:none;}
.stButton > button:hover {background:linear-gradient(90deg,#1d4ed8,#2563eb);}
.stMultiSelect, .stSelectbox {background-color:white !important; border-radius:8px;}
[data-testid="stDataFrame"] {background-color:white; border-radius:10px; box-shadow:0 4px 14px rgba(0,0,0,0.08);}
.stAlert {border-radius:10px;}
</style>
""", unsafe_allow_html=True)

# -----------------------------
st.title("🚀 Agentic Test Automation Dashboard")
st.write("Enterprise Performance | Load | Batch | UI Testing")

TEST_OPTIONS = [
    "API Performance Testing",
    "ISO8583 Transaction Testing",
    "Web UI Load Testing",
    "Batch Job Performance Testing"
]

selected_tests = st.multiselect(
    "🔽 Select Tests to Execute",
    TEST_OPTIONS,
    default=TEST_OPTIONS
)

run_button = st.button("▶ Run Selected Tests")

BASE_DIR = os.getcwd()
MAX_RUNS = 7

# -----------------------------
def create_run_folder():
    existing = sorted([f for f in os.listdir(BASE_DIR) if f.startswith("TestRun_")])
    while len(existing) >= MAX_RUNS:
        shutil.rmtree(os.path.join(BASE_DIR, existing.pop(0)), ignore_errors=True)
    run_dir = os.path.join(BASE_DIR, f"TestRun_{strftime('%Y%m%d_%H%M%S')}")
    os.makedirs(run_dir, exist_ok=True)
    os.makedirs(os.path.join(run_dir, "jmx_scripts"), exist_ok=True)  # Folder for JMX scripts
    return run_dir

# -----------------------------
def generate_summary(df, test_name, run_dir, key_col):
    total = len(df)
    success = int(df['success'].sum())
    fail = total - success
    avg_rt = round(df[key_col].mean(), 2)
    min_rt = df[key_col].min()
    max_rt = df[key_col].max()

    images = []

    # Trend
    plt.figure(figsize=(4,3))
    plt.plot(df[key_col], marker='o')
    img = os.path.join(run_dir, f"{test_name}_trend.png")
    plt.title("Response Trend")
    plt.savefig(img); plt.close()
    images.append(img)

    # Histogram
    plt.figure(figsize=(4,3))
    plt.hist(df[key_col], bins=8)
    img = os.path.join(run_dir, f"{test_name}_hist.png")
    plt.title("Distribution")
    plt.savefig(img); plt.close()
    images.append(img)

    # Pie
    plt.figure(figsize=(4,3))
    plt.pie([success, fail], labels=["Success","Fail"], autopct='%1.1f%%')
    img = os.path.join(run_dir, f"{test_name}_pie.png")
    plt.title("Success Ratio")
    plt.savefig(img); plt.close()
    images.append(img)

    # Horizontal Bar
    plt.figure(figsize=(4,2))
    plt.barh(["Success","Fail"],[success,fail])
    img = os.path.join(run_dir, f"{test_name}_bar.png")
    plt.title("Execution Result")
    plt.savefig(img); plt.close()
    images.append(img)

    # Save CSV
    csv_file = os.path.join(run_dir, f"{test_name}_logs.csv")
    df.to_csv(csv_file, index=False)

    # Dummy JMX file
    jmx_file = os.path.join(run_dir, "jmx_scripts", f"{test_name}.jmx")
    with open(jmx_file, "w") as f:
        f.write(f"<!-- Dummy {test_name} JMX script -->\n")

    summary = pd.DataFrame([{
        "Test": test_name,
        "Total": total,
        "Success": success,
        "Fail": fail,
        "Avg(ms)": avg_rt,
        "Min(ms)": min_rt,
        "Max(ms)": max_rt
    }])

    return summary, images

# -----------------------------
def display_graphs(images):
    cols = st.columns(len(images))
    for col, img in zip(cols, images):
        col.image(img, use_container_width=True)

# -----------------------------
def run_api_test(run_dir):
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.subheader("🔹 API Performance Testing")

    app = Flask(__name__)
    @app.route('/balance')
    def balance(): return jsonify({'balance':1000})

    threading.Thread(target=lambda: app.run(port=8080), daemon=True).start()
    sleep(1)

    data=[]
    for _ in range(10):
        s=time.time()
        r=requests.get("http://127.0.0.1:8080/balance")
        data.append({"response_time":(time.time()-s)*1000,"success":r.status_code==200})

    df=pd.DataFrame(data)
    return generate_summary(df,"API",run_dir,"response_time")

# -----------------------------
def run_iso_test(run_dir):
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.subheader("🔹 ISO8583 Performance Testing")
    df=pd.DataFrame({
        "response_time":[220,240,260,280,300,400],
        "success":[1,1,1,1,0,1]
    })
    return generate_summary(df,"ISO8583",run_dir,"response_time")

# -----------------------------
def run_webui_test(run_dir):
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.subheader("🔹 Web UI Load Testing")
    df=pd.DataFrame({
        "response_time":[120,130,140,160,200],
        "success":[1,1,1,0,1]
    })
    return generate_summary(df,"WebUI",run_dir,"response_time")

# -----------------------------
def run_batch_test(run_dir):
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.subheader("🔹 Batch Job Performance Testing")
    df=pd.DataFrame({
        "response_time":[2100,2500,3000],
        "success":[1,1,1]
    })
    return generate_summary(df,"Batch",run_dir,"response_time")

# -----------------------------
if run_button and selected_tests:
    run_dir = create_run_folder()
    st.success(f"📁 Artifacts stored in: {run_dir}")

    summaries = []

    if "API Performance Testing" in selected_tests:
        s, imgs = run_api_test(run_dir)
        summaries.append(s)
        display_graphs(imgs)

    if "ISO8583 Transaction Testing" in selected_tests:
        s, imgs = run_iso_test(run_dir)
        summaries.append(s)
        display_graphs(imgs)

    if "Web UI Load Testing" in selected_tests:
        s, imgs = run_webui_test(run_dir)
        summaries.append(s)
        display_graphs(imgs)

    if "Batch Job Performance Testing" in selected_tests:
        s, imgs = run_batch_test(run_dir)
        summaries.append(s)
        display_graphs(imgs)

    final = pd.concat(summaries)
    st.subheader("📊 Overall Execution Summary")
    st.dataframe(final, use_container_width=True)

    # 🎯 KPI Tiles
    total_tests = final['Total'].sum()
    total_success = final['Success'].sum()
    total_fail = final['Fail'].sum()
    avg_ms = round(final['Avg(ms)'].mean(),2)

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("🧪 Total Requests", total_tests)
    k2.metric("✅ Success", total_success)
    k3.metric("❌ Fail", total_fail)
    k4.metric("⏱️ Avg Response (ms)", avg_ms)

    # Save overall CSV
    final.to_csv(os.path.join(run_dir,"Overall_Summary.csv"), index=False)

    st.balloons()
