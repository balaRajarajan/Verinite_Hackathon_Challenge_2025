package com.verinite.bank.service;

import com.verinite.bank.dto.BankDto;
import com.verinite.bank.dto.KycResultDto;
import com.verinite.bank.entity.BankEntity;
import com.verinite.bank.entity.KycResultEntity;
import com.verinite.bank.repository.BankRepo;
import com.verinite.bank.repository.KycResultRepo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;


@Slf4j
@Service
@RequiredArgsConstructor
public class BankService {

    private final BankRepo bankRepo;
    private final KycResultRepo kycResultRepo;

    public Long saveApplication(BankDto dto, MultipartFile[] photos, MultipartFile signature) throws IOException {

        BankEntity entity = BankEntity.builder()
                .mobile(dto.getMobile())
                .email(dto.getEmail())
                .pan(dto.getPan())
                .aadhaar(dto.getAadhaar())
                .fullName(dto.getFullName())
                .dob(dto.getDob())
                .gender(dto.getGender())
                .fatherName(dto.getFatherName())
                .maritalStatus(dto.getMaritalStatus())
                .occupation(dto.getOccupation())
                .annualIncome(dto.getAnnualIncome())
                .nationality(dto.getNationality())
                .photo1(photos[0].getBytes())
                .photo2(photos[1].getBytes())
                .signature(signature.getBytes())
                .status("APPLICATION_SUBMITTED")
                .build();

        BankEntity saved = bankRepo.save(entity);

        return saved.getId();  // return id for next step
    }

    public String verifyId(Long applicationId) {

        BankEntity entity = bankRepo.findById(applicationId)
                .orElseThrow(() -> new RuntimeException("Application not found"));

        // 🔥 Simulate ID Verification Logic
        if (entity.getPan() != null && entity.getAadhaar() != null) {

            entity.setStatus("ID_VERIFIED");
            bankRepo.save(entity);

            return "ID Verification Successful ✅";
        }

        throw new RuntimeException("ID Verification Failed ❌");
    }

    public String getStatus(Long id) {
        BankEntity entity = bankRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Not found"));

        return entity.getStatus(); // you must have status column
    }

    public void startKyc(Long id) {

        log.info("Initiating KYC for application id: {}", id);

        BankEntity application = bankRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Application not found"));

        application.setStatus("KYC_IN_PROGRESS");
        bankRepo.save(application);

        log.info("KYC marked as IN_PROGRESS for id: {}", id);
    }

    public void completeKyc(Long id, KycResultDto dto) {

        BankEntity application = bankRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Application not found"));

        KycResultEntity kyc = new KycResultEntity();

        kyc.setAadhaarNumber(dto.getAadhaarNumber());
        kyc.setName(dto.getName());
        kyc.setDob(dto.getDob());
        kyc.setGender(dto.getGender());
        kyc.setOcrConfidenceScore(dto.getOcrConfidenceScore());
        kyc.setIsBlurry(dto.getIsBlurry());
        kyc.setBlurScore(dto.getBlurScore());

        kyc.setApplication(application);

        kycResultRepo.save(kyc);

        application.setStatus("KYC_COMPLETED");
        bankRepo.save(application);
    }

    public void saveKycResult(Long id, KycResultDto dto) {

        BankEntity application = bankRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Application not found"));

        KycResultEntity kyc = new KycResultEntity();

        String cleanedAadhaar = dto.getAadhaarNumber().replaceAll("\\s+", "");

        kyc.setAadhaarNumber(cleanedAadhaar);
        kyc.setName(dto.getName());
        kyc.setDob(dto.getDob());
        kyc.setGender(dto.getGender());
        kyc.setOcrConfidenceScore(dto.getOcrConfidenceScore());
        kyc.setIsBlurry(dto.getIsBlurry());
        kyc.setBlurScore(dto.getBlurScore());
        kyc.setApplication(application);

        kycResultRepo.save(kyc);

        application.setStatus("KYC_COMPLETED");
        bankRepo.save(application);

        log.info("KYC completed for application id: {}", id);
    }



}

