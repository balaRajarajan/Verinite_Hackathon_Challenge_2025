package com.verinite.bank.entity;

import jakarta.persistence.*;
import lombok.*;

import java.io.InputStream;

@Entity
@Table(name = "account_applications")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class BankEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String mobile;
    private String email;
    private String pan;
    private String aadhaar;

    private String fullName;
    private String dob;
    private String gender;
    private String fatherName;
    private String maritalStatus;
    private String occupation;
    private Double annualIncome;
    private String nationality;

    @Lob
    @Column(columnDefinition = "LONGBLOB")
    private byte[] photo1;

    @Lob
    @Column(columnDefinition = "LONGBLOB")
    private byte[] photo2;

    @Lob
    @Column(columnDefinition = "LONGBLOB")
    private byte[] signature;

    private String status;


}
