package com.verinite.bank.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "aadhaar_details_ai")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class KycResultEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String aadhaarNumber;

    private String name;
    private String dob;
    private String gender;

    private Double ocrConfidenceScore;
    private Boolean isBlurry;
    private Double blurScore;

    @Column(updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();


    @ManyToOne
    @JoinColumn(name = "application_id")
    private BankEntity application;
}
