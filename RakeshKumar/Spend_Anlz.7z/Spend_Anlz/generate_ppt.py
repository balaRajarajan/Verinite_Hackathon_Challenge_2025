import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN

# --- CONFIGURATION ---
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_FILE = os.path.join(SCRIPT_DIR, 'transactions_1.csv')
IMG_DIR = os.path.join(SCRIPT_DIR, 'generated_charts')
PPT_OUTPUT = os.path.join(SCRIPT_DIR, 'Spend_Analysis_Report.pptx')

# Ensure image directory exists
if not os.path.exists(IMG_DIR):
    os.makedirs(IMG_DIR)

# --- STEP 0: MOCK DATA GENERATOR (If CSV is missing) ---
if not os.path.exists(CSV_FILE):
    print("CSV not found. Generating dummy data for demonstration...")
    data = {
        'Customer_id': ['C001', 'C001', 'C002', 'C002', 'C003', 'C004'],
        'month': ['Jan', 'Feb', 'Jan', 'Feb', 'Jan', 'Jan'],
        'total_spend': [1200, 1500, 800, 950, 2100, 500],
        'domestic_cnt': [5, 6, 2, 3, 10, 1],
        'International_cnt': [1, 2, 0, 0, 5, 0],
        'online_spend': [600, 700, 400, 500, 1000, 100],
        'instore_spend': [400, 500, 300, 300, 500, 300],
        'travel_spend': [100, 200, 0, 50, 500, 0],
        'fuel_spend': [50, 50, 100, 100, 50, 50],
        'atm_withdrawal': [50, 50, 0, 0, 50, 50],
        'txn_count': [6, 8, 2, 3, 15, 1],
        'avg_txn_amount': [200, 187.5, 400, 316, 140, 500]
    }
    pd.DataFrame(data).to_csv(CSV_FILE, index=False)

# --- STEP 1: LOAD AND CLEAN DATA ---
print("Loading data...")
df = pd.read_csv(CSV_FILE)
df.columns = df.columns.str.strip()
df['Customer_id'] = df['Customer_id'].str.strip()
df['month'] = df['month'].str.strip()
df = df.sort_values(['Customer_id', 'month'])
customers = df['Customer_id'].unique()

# --- STEP 2: CHART GENERATION FUNCTIONS ---
# We modify your plotting code to save files instead of showing them.

def save_chart(fig, filename):
    path = os.path.join(IMG_DIR, filename)
    fig.savefig(path, dpi=100, bbox_inches='tight')
    plt.close(fig)
    return path

print("Generating charts...")

# Chart 1: Monthly Performance
fig1, ax = plt.subplots(figsize=(10, 6))
months = df['month'].unique()
x = np.arange(len(months))
width = 0.12
for i, customer in enumerate(customers):
    c_data = df[df['Customer_id'] == customer].sort_values('month')
    spending = []
    for m in sorted(months):
        val = c_data[c_data['month'] == m]['total_spend'].values
        spending.append(val[0] if len(val) > 0 else 0)
    ax.bar(x + (i * width), spending, width, label=customer, alpha=0.8)
ax.set_title('Monthly Performance Comparison', fontsize=14, fontweight='bold')
ax.set_xticks(x + (width * (len(customers) - 1) / 2))
ax.set_xticklabels(sorted(months))
ax.legend()
chart1_path = save_chart(fig1, 'monthly_comparison.png')

# Chart 2: Total Spend Distribution (Pie)
fig2, ax = plt.subplots(figsize=(8, 6))
cust_spend = df.groupby('Customer_id')['total_spend'].sum().sort_values(ascending=False)
colors = plt.cm.Set3(np.linspace(0, 1, len(cust_spend)))
ax.pie(cust_spend, labels=cust_spend.index, autopct='%1.1f%%', colors=colors, startangle=90)
ax.set_title('Total Spend Share by Customer', fontsize=14, fontweight='bold')
chart2_path = save_chart(fig2, 'total_spend_pie.png')

# Chart 3: Domestic vs International
fig3, ax = plt.subplots(figsize=(10, 6))
dom_intl = df.groupby('Customer_id')[['domestic_cnt', 'International_cnt']].sum()
dom_intl['Total'] = dom_intl.sum(axis=1)
dom_intl = dom_intl.sort_values('Total', ascending=False)
x = np.arange(len(dom_intl))
w = 0.35
ax.bar(x - w/2, dom_intl['domestic_cnt'], w, label='Domestic', color='steelblue')
ax.bar(x + w/2, dom_intl['International_cnt'], w, label='International', color='coral')
ax.set_xticks(x)
ax.set_xticklabels(dom_intl.index)
ax.legend()
ax.set_title('Transaction Volume: Domestic vs International', fontsize=14, fontweight='bold')
chart3_path = save_chart(fig3, 'dom_intl.png')

# Chart 4: Top Customers Category Breakdown
fig4, axes = plt.subplots(2, 3, figsize=(16, 10))
axes = axes.flatten()
spend_cols = ['online_spend', 'instore_spend', 'travel_spend', 'fuel_spend', 'atm_withdrawal']
cat_df = df.groupby('Customer_id')[spend_cols].sum()
top_cust = df.groupby('Customer_id')['total_spend'].sum().nlargest(6).index
for idx, c in enumerate(top_cust):
    if idx < len(axes):
        data = cat_df.loc[c]
        data = data[data > 0]
        axes[idx].pie(data, labels=data.index, autopct='%1.1f%%', startangle=90)
        axes[idx].set_title(f'{c} Breakdown')
# Hide unused
for idx in range(len(top_cust), len(axes)):
    axes[idx].axis('off')
fig4.suptitle('Category Spend - Top Customers', fontsize=16, fontweight='bold')
chart4_path = save_chart(fig4, 'category_breakdown.png')


# --- STEP 3: PPT GENERATION ---
print("Building PowerPoint presentation...")

prs = Presentation()

def add_slide(title, image_path=None, text_content=None):
    """Helper to add a standardized slide"""
    slide = prs.slides.add_slide(prs.slide_layouts[1 if image_path else 1])
    
    # Title
    title_shape = slide.shapes.title
    title_shape.text = title
    
    # Image
    if image_path:
        # Calculate image size to fit nicely
        left = Inches(1)
        top = Inches(2)
        width = Inches(8)
        height = Inches(4.5)
        slide.shapes.add_picture(image_path, left, top, width=width)
        
    # Text (Optional)
    if text_content:
        tf = slide.placeholders[1].text_frame
        tf.text = text_content

# Slide 1: Title
title_slide = prs.slides.add_slide(prs.slide_layouts[0])
title_slide.shapes.title.text = "Customer Spend Analysis Report"
title_slide.placeholders[1].text = "Generated via Python Automated Analysis"

# Slide 2: Executive Summary (Calculated)
total_rev = df['total_spend'].sum()
top_spender = df.groupby('Customer_id')['total_spend'].sum().idxmax()
avg_tx = df['avg_txn_amount'].mean()
summary_text = (
    f"Total Revenue Analyzed: ${total_rev:,.2f}\n"
    f"Top Spender: {top_spender}\n"
    f"Average Transaction Value: ${avg_tx:.2f}\n"
    f"Unique Customers: {len(customers)}"
)
add_slide("Executive Summary", text_content=summary_text)

# Slide 3: Monthly Comparison
add_slide("Monthly Spending Trends", image_path=chart1_path)

# Slide 4: Customer Share
add_slide("Revenue Distribution", image_path=chart2_path)

# Slide 5: Transaction Types
add_slide("Transaction Types (Domestic vs Intl)", image_path=chart3_path)

# Slide 6: Category Breakdown
add_slide("Spend Categories (Top Customers)", image_path=chart4_path)

# Slide 7: Detailed Data Table
slide = prs.slides.add_slide(prs.slide_layouts[5]) # Title Only
slide.shapes.title.text = "Summary Statistics"

# Add a table to the slide
rows = len(customers) + 1
cols = 4
left = Inches(1)
top = Inches(2)
width = Inches(8)
height = Inches(0.8)

table = slide.shapes.add_table(rows, cols, left, top, width, height).table

# Column Headers
headers = ['Customer ID', 'Total Spend', 'Txn Count', 'Avg Txn Amt']
for i, h in enumerate(headers):
    table.cell(0, i).text = h

# Fill Rows
summary_df = df.groupby('Customer_id').agg({
    'total_spend': 'sum',
    'txn_count': 'sum',
    'avg_txn_amount': 'mean'
}).reset_index()

for i, row in summary_df.iterrows():
    table.cell(i+1, 0).text = str(row['Customer_id'])
    table.cell(i+1, 1).text = f"${row['total_spend']:,.2f}"
    table.cell(i+1, 2).text = str(int(row['txn_count']))
    table.cell(i+1, 3).text = f"${row['avg_txn_amount']:,.2f}"

# --- STEP 4: SAVE ---
prs.save(PPT_OUTPUT)
print(f"Success! Presentation saved to: {PPT_OUTPUT}")