package com.verinite.bank.controller;

import com.verinite.bank.dto.BankDto;
import com.verinite.bank.dto.KycResultDto;
import com.verinite.bank.service.BankService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api/bank")
@CrossOrigin(origins = "http://localhost:5173")
@RequiredArgsConstructor
@Slf4j
public class BankController {

    private final BankService bankService;

    @PostMapping(value = "/submit", consumes = {"multipart/form-data"})
    public ResponseEntity<?> submitApplication( @ModelAttribute BankDto dto, @RequestPart("photos") MultipartFile[] photos, @RequestPart("signature") MultipartFile signature) throws Exception {

        if (photos.length != 2) {
            return ResponseEntity.badRequest()
                    .body("Upload exactly 2 passport photos");
        }

        Long id = bankService.saveApplication(dto, photos, signature);

        return ResponseEntity.ok(id);   // 🔥 RETURN ID
    }

    @PostMapping("/id-verification/{id}")
    public ResponseEntity<?> verifyId(@PathVariable Long id) {

        String result = bankService.verifyId(id);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/status/{id}")
    public ResponseEntity<?> getApplicationStatus(@PathVariable Long id) {
        return ResponseEntity.ok(bankService.getStatus(id));
    }

    @PostMapping("/start-kyc/{id}")
    public ResponseEntity<?> startKyc(@PathVariable Long id) {
        log.info("Starting KYC for application id: {}", id);
        bankService.startKyc(id);
        return ResponseEntity.ok("KYC Process Started");
    }

    @PostMapping("/complete-kyc/{id}")
    public ResponseEntity<?> completeKyc( @PathVariable Long id, @RequestBody KycResultDto dto) {

        bankService.completeKyc(id, dto);
        return ResponseEntity.ok("KYC Completed");
    }

    @PostMapping("/save-kyc/{id}")
    public ResponseEntity<?> saveKyc( @PathVariable Long id, @RequestBody KycResultDto dto) {

        bankService.saveKycResult(id, dto);
        return ResponseEntity.ok("KYC saved successfully");
    }



}
