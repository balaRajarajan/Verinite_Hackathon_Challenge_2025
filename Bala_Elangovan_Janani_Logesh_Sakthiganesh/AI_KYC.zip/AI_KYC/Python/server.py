from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware

import cv2
import numpy as np
import os
import time
import re

from sklearn.metrics.pairwise import cosine_similarity
from insightface.app import FaceAnalysis
from text import extract_aadhaar_data
import mysql.connector


cached_embedding = None
cached_user_id = None
cached_name = None
cached_aadhaar = None


# ================= Database Connectivity =================


def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="verinite_bank"
    )

# ================= APP =================
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
AADHAAR_DIR = os.path.join(BASE_DIR, "snapshots", "aadhaar")
os.makedirs(AADHAAR_DIR, exist_ok=True)

# ================= STATE =================
STAGE = "FACE"
face_timer_start = None
card_captured = False

# ================= FACE =================
face_app = FaceAnalysis(name="buffalo_l", providers=["CPUExecutionProvider"])
face_app.prepare(ctx_id=0, det_size=(640, 640))


def get_user_data(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(
        "SELECT photo1, full_name, aadhaar FROM account_applications WHERE id=%s",
        (user_id,)
    )

    result = cursor.fetchone()
    conn.close()

    if result is None:
        return None, None, None

    return result[0], result[1], result[2]

def db_image_to_cv2(image_bytes):
    nparr = np.frombuffer(image_bytes, np.uint8)
    return cv2.imdecode(nparr, cv2.IMREAD_COLOR)

# ================= VALIDATION =================
def is_valid_data(data):
    try:
        aadhaar = re.sub(r"\s+", "", str(data.get("aadhaar_number", "")))
        if len(aadhaar) != 12 or not aadhaar.isdigit():
            return False

        if len(data.get("name", "")) < 3:
            return False

        if not re.match(r"\d{2}/\d{2}/\d{4}", data.get("dob", "")):
            return False

        if data.get("gender") not in ["Male", "Female"]:
            return False

        return True
    except:
        return False

# ================= RESET =================
@app.post("/reset")
def reset():
    global STAGE, face_timer_start, card_captured
    global cached_embedding, cached_user_id, cached_name, cached_aadhaar

    STAGE = "FACE"
    face_timer_start = None
    card_captured = False

    # 🔥 ADD THIS
    cached_embedding = None
    cached_user_id = None
    cached_name = None
    cached_aadhaar = None

    print("🔄 RESET DONE")
    return {"status": "reset"}


# ================= DETECT =================
@app.post("/detect")
# async def detect(file: UploadFile = File(...)):
async def detect(file: UploadFile = File(...), user_id: int = Form(...)):

    global STAGE, face_timer_start, card_captured

    print("\n👉 CURRENT STAGE:", STAGE)

    contents = await file.read()
    frame = cv2.imdecode(np.frombuffer(contents, np.uint8), cv2.IMREAD_COLOR)

    if frame is None:
        return JSONResponse({"status": "Invalid frame"})

    # ================= FACE =================

    

    if STAGE == "FACE":
        if user_id == 0:
                return {"stage": "FACE", "status": "Invalid user_id"}
        
        faces = face_app.get(frame)

        if not faces:
            face_timer_start = None
            return {"stage": "FACE", "status": "No face"}
        
        if len(faces) > 1:
            return {"stage": "FACE", "status": "Multiple faces detected"}

        emb = faces[0].embedding.reshape(1, -1)

        global cached_embedding, cached_user_id, cached_name, cached_aadhaar

        if cached_embedding is None or cached_user_id != user_id:

            image_bytes, name, db_aadhaar = get_user_data(user_id)

            if image_bytes is None:
                return {"stage": "FACE", "status": "No image in DB"}

            if not db_aadhaar:
                return {"stage": "FACE", "status": "No Aadhaar in DB"}
            
            db_img = db_image_to_cv2(image_bytes)

            if db_img is None:
                return {"stage": "FACE", "status": "Invalid DB image"}

            db_faces = face_app.get(db_img)

            if not db_faces:
                return {"stage": "FACE", "status": "No face in DB image"}
            
            if len(db_faces) > 1:
                return {"stage": "FACE", "status": "Multiple faces in DB image"}

            cached_embedding = db_faces[0].embedding.reshape(1, -1)
            cached_user_id = user_id
            cached_name = name
            cached_aadhaar = db_aadhaar

        known_embedding = cached_embedding

        # Compare with live face
        similarity = cosine_similarity(emb, known_embedding)[0][0]


        print("DB Face similarity:", similarity)

        if similarity < 0.45:
            face_timer_start = None
            return {"stage": "FACE", "status": "Unknown"}
        
        
#===================================

        if face_timer_start is None:
            face_timer_start = time.time()

        if time.time() - face_timer_start >= 2:
            STAGE = "CARD"
            print("🔥 SWITCHED TO CARD STAGE")
            return {"stage": "CARD", "status": "Show Aadhaar"}

        return {
            "stage": "FACE",
            "status": f"Face Detecting: {cached_name or 'User'}"
        }

    # ================= CARD =================
    if STAGE == "CARD":

        print("🟢 CARD STAGE (GUIDED)")

        h, w, _ = frame.shape

        # same as frontend box
        box_w = int(w * 0.6)
        box_h = int(box_w / 1.6)

        x = int((w - box_w) / 2)
        y = int((h - box_h) / 2)

        # 🔥 ADD PADDING
        pad = 40

        crop = frame[
            max(0, y - pad): min(h, y + box_h + pad),
            max(0, x - pad): min(w, x + box_w + pad)
        ]

        cv2.imwrite("debug_crop.jpg", crop)

        filename = f"aadhaar_{int(time.time())}.jpg"
        path = os.path.join(AADHAAR_DIR, filename)
        cv2.imwrite(path, crop)

        print("📸 CAPTURED FROM CENTER")

        result = extract_aadhaar_data(path)
        print("OCR:", result)


        if not result.get("aadhaar_number"):
            return {"stage": "CARD", "status": "Move closer / hold steady"}

        if not is_valid_data(result):
            return {"stage": "CARD", "status": "Invalid data"}
        
        if not cached_aadhaar:
            return {
                "stage": "CARD",
                "status": "No Aadhaar in DB ❌"
            }

        # 🔥 Aadhaar match check
        db_aadhaar_clean = re.sub(r"\s+", "", str(cached_aadhaar))
        ocr_aadhaar = re.sub(r"\s+", "", result.get("aadhaar_number", ""))

        if ocr_aadhaar != db_aadhaar_clean:
            return {
                "stage": "CARD",
                "status": "Aadhaar mismatch ❌"
            }

        STAGE = "DONE"

        return {
            "stage": "DONE",
            "data": result
        }


    return {"stage": "DONE"}