import React, { useState, useEffect } from "react";
import "./account.css";
import {
  submitApplication,
  getApplicationStatus
} from "../api/bankApi";
import FaceAadhaarKYC from "./FaceAadhaarKYC";

export default function AccountOpening() {

  const [isKycChecked, setIsKycChecked] = useState(false);
  const [isTermsChecked, setIsTermsChecked] = useState(false);

  const [currentStep, setCurrentStep] = useState(1);
  const [completedSteps, setCompletedSteps] = useState([]);
  const [showKyc, setShowKyc] = useState(false);

  /* ================= STEP LOGIC ================= */

  const getStepClass = (step) => {
    if (completedSteps.includes(step)) return "step completed";
    if (currentStep === step) return "step active";
    return "step";
  };

  const getLineClass = (step) => {
    if (completedSteps.includes(step)) return "line completed-line";
    if (currentStep === step) return "line active-line";
    return "line";
  };

  /* ================= SUBMIT APPLICATION ================= */

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData(e.target);

    try {
      setCurrentStep(1);

      const applicationId = await submitApplication(formData);

      // Save application id for refresh restore
      localStorage.setItem("applicationId", applicationId);

      setCompletedSteps([1]);
      setCurrentStep(2);

      alert("Application Submitted Successfully ✅");

    } catch (error) {
      console.error(error);
      alert("Submission failed ❌");
    }
  };

  /* ================= NEXT PROCESS ================= */

  const handleNextProcess = async () => {
    try {
      const id = localStorage.getItem("applicationId");
      if (!id) return alert("No application found");

      const status = await getApplicationStatus(id);

      if (status === "APPLICATION_SUBMITTED") {
        setCompletedSteps([1]);
        setCurrentStep(2);
        alert("Application Submitted successfully, Please wait for ID verification check ⏳");
      }

      if (status === "ID_VERIFIED") {
        setCompletedSteps([1, 2]);
        setCurrentStep(3);
        setShowKyc(true); // 🔥 show KYC component
      }

      if (status === "KYC_COMPLETED") {
        setCompletedSteps([1, 2, 3]);
        setCurrentStep(4);
        setShowKyc(false);
      }

      if (status === "UNDERWRITING_COMPLETED") {
        setCompletedSteps([1, 2, 3, 4]);
        setCurrentStep(5);
        setShowKyc(false);
      }

    } catch (error) {
      console.error(error);
      alert("Failed to fetch status ❌");
    }
  };

  /* ================= RESTORE AFTER REFRESH ================= */

  useEffect(() => {
    const id = localStorage.getItem("applicationId");
    if (!id) return;

    const fetchStatus = async () => {
      try {
        const status = await getApplicationStatus(id);

        if (status === "APPLICATION_SUBMITTED") {
          setCompletedSteps([1]);
          setCurrentStep(2);
        }

        if (status === "ID_VERIFIED") {
          setCompletedSteps([1, 2]);
          setCurrentStep(3);
          setShowKyc(true);
        }

        if (status === "KYC_COMPLETED") {
          setCompletedSteps([1, 2, 3]);
          setCurrentStep(4);
        }

        if (status === "UNDERWRITING_COMPLETED") {
          setCompletedSteps([1, 2, 3, 4]);
          setCurrentStep(5);
        }

      } catch (err) {
        console.error(err);
      }
    };

    fetchStatus();
  }, []);

  /* ================= UI ================= */

  return (
    <div className="page">

      {/* HEADER */}
      <header className="header">
        <div className="logo">VERINITE BANK</div>
      </header>

      {/* HERO */}
      <section className="hero">
        <div>
          <h1>Get Interest Credited Every Month</h1>
          <p>With your Verinite Bank Savings Account</p>
        </div>
      </section>

      {/* PROCESS STEPPER */}
      <section className="form-section">
        <div className="process-container">
          {[1, 2, 3, 4, 5].map((step) => (
            <React.Fragment key={step}>
              <div className={getStepClass(step)}>
                <div className="circle">{step}</div>
                <p>
                  {step === 1 && "Application"}
                  {step === 2 && "ID Verification"}
                  {step === 3 && "KYC"}
                  {step === 4 && "Underwriting"}
                  {step === 5 && "Decision"}
                </p>
              </div>
              {step !== 5 && <div className={getLineClass(step)}></div>}
            </React.Fragment>
          ))}
        </div>
      </section>

      {/* SHOW FORM ONLY IF KYC NOT STARTED */}
      {!showKyc && (
        <form onSubmit={handleSubmit}>

          {/* BASIC DETAILS */}
          <section className="form-section">
            <h2>Basic Details</h2>
            <div className="form-grid">
              <input name="mobile" type="tel" placeholder="Mobile Number" required />
              <input name="email" type="email" placeholder="Email Address" required />
              <input name="pan" type="text" placeholder="Permanent Account Number (PAN)" required />
              <input name="aadhaar" type="text" placeholder="12-digit Aadhaar Number" required />
            </div>
          </section>

          {/* PROFESSIONAL DETAILS */}
          <section className="form-section">
            <h2>Professional & Personal Details</h2>
            <div className="form-grid">

              <input name="fullName" type="text" placeholder="Full Name (as per Aadhaar/PAN)" required />
              <input name="dob" type="date" required />

              <select name="gender" required>
                <option value="">Select Gender</option>
                <option>Male</option>
                <option>Female</option>
                <option>Other</option>
              </select>

              <input name="fatherName" type="text" placeholder="Father’s / Mother’s Name" required />

              <select name="maritalStatus" required>
                <option value="">Marital Status</option>
                <option>Single</option>
                <option>Married</option>
                <option>Divorced</option>
                <option>Widowed</option>
              </select>

              <select name="occupation" required>
                <option value="">Occupation</option>
                <option>Salaried</option>
                <option>Self Employed</option>
                <option>Business</option>
                <option>Student</option>
                <option>Retired</option>
                <option>Government</option>
                <option>Private Sector</option>
              </select>

              <input name="annualIncome" type="number" placeholder="Annual Income (₹)" required />

              <select name="nationality" required>
                <option value="">Select Nationality</option>
                <option>Indian</option>
                <option>NRI</option>
                <option>Foreign National</option>
              </select>

              <div className="file-upload">
                <label>Upload 2 Passport Size Photos</label>
                <input type="file" name="photos" accept="image/*" multiple required />
              </div>

              <div className="file-upload">
                <label>Upload Digital Signature</label>
                <input type="file" name="signature" accept="image/*" required />
              </div>

            </div>
          </section>

          {/* DISCLAIMER */}
          <section className="form-section">

            <div className="check">
              <input
                type="checkbox"
                checked={isKycChecked}
                onChange={(e) => setIsKycChecked(e.target.checked)}
              />
              Complete KYC within 30 days
            </div>

            <div className="check">
              <input
                type="checkbox"
                checked={isTermsChecked}
                onChange={(e) => setIsTermsChecked(e.target.checked)}
              />
              Accept Terms & Conditions
            </div>

            <button
              type="submit"
              className="proceed-btn"
              disabled={!(isKycChecked && isTermsChecked)}
            >
              Submit Application
            </button>

            <button
              type="button"
              className="proceed-btn"
              onClick={handleNextProcess}
            >
              Next Process
            </button>

          </section>

        </form>
      )}

      {/* SHOW KYC SCREEN */}
      {showKyc && <FaceAadhaarKYC />}

      <footer className="footer">
        <p>© 2026 Verinite Bank Ltd. All Rights Reserved.</p>
      </footer>

    </div>
  );
}
