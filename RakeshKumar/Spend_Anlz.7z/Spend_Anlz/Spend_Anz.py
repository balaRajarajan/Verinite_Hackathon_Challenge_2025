import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os

# Get the directory of the current script
script_dir = os.path.dirname(os.path.abspath(__file__))
csv_file = os.path.join(script_dir, 'transactions_1.csv')

# Load the transaction data
df = pd.read_csv(csv_file)
#df = pd.read_csv("transactions_1.csv", skipinitialspace=True)
# Clean up whitespace in columns
df.columns = df.columns.str.strip()
df['Customer_id'] = df['Customer_id'].str.strip()
df['month'] = df['month'].str.strip()

# Sort by customer and month
df = df.sort_values(['Customer_id', 'month'])

# Get unique customers
customers = df['Customer_id'].unique()

print(f"\nFound {len(customers)} unique customers")

# Create a combined comparison chart
print("\n" + "="*50)
print("=== Combined Customer Comparison ===\n")

fig, ax = plt.subplots(figsize=(14, 7))

# Prepare data for grouped bar chart
months = df['month'].unique()
x = np.arange(len(months))
width = 0.12

for i, customer in enumerate(customers):
    customer_data = df[df['Customer_id'] == customer].sort_values('month')
    # Reindex to match all months
    spending_by_month = []
    for month in sorted(months):
        month_data = customer_data[customer_data['month'] == month]
        if not month_data.empty:
            spending_by_month.append(month_data['total_spend'].values[0])
        else:
            spending_by_month.append(0)
    
    ax.bar(x + (i * width), spending_by_month, width, label=customer, alpha=0.8)

ax.set_xlabel('Month', fontsize=12, fontweight='bold')
ax.set_ylabel('Total Spend ($)', fontsize=12, fontweight='bold')
ax.set_title('Monthly Performance Comparison - All Customers', fontsize=14, fontweight='bold')
ax.set_xticks(x + (width * (len(customers) - 1) / 2))
ax.set_xticklabels(sorted(months), rotation=45, ha='right')
ax.legend(title='Customer ID', loc='upper left')
ax.grid(axis='y', alpha=0.3, linestyle='--')
ax.set_axisbelow(True)

plt.tight_layout()
plt.show()

# Create pie chart - Customer ID wise spend
print("\n" + "="*50)
print("=== Customer ID Wise Spend Distribution ===\n")

fig, ax = plt.subplots(figsize=(12, 8))

# Get total spend by customer
customer_spend = df.groupby('Customer_id')['total_spend'].sum().sort_values(ascending=False)

# Create pie chart
colors = plt.cm.Set3(np.linspace(0, 1, len(customer_spend)))
wedges, texts, autotexts = ax.pie(customer_spend, labels=customer_spend.index, autopct='%1.1f%%',
                                    colors=colors, startangle=90, textprops={'fontsize': 10})

# Enhance the appearance
ax.set_title('Total Spend Distribution by Customer ID', fontsize=14, fontweight='bold', pad=20)

# Make percentage text bold
for autotext in autotexts:
    autotext.set_color('white')
    autotext.set_fontweight('bold')
    autotext.set_fontsize(9)

plt.tight_layout()
plt.show()

# Print spend breakdown
print("Spend Distribution by Customer:")
for customer, spend in customer_spend.items():
    percentage = (spend / customer_spend.sum()) * 100
    print(f"  {customer}: ${spend:,} ({percentage:.1f}%)")

# Create bar chart - Customer wise Domestic vs International transactions
print("\n" + "="*50)
print("=== Customer Wise Domestic vs International Transactions ===\n")

fig, ax = plt.subplots(figsize=(14, 7))

# Get domestic and international counts by customer
domestic_intl = df.groupby('Customer_id')[['domestic_cnt', 'International_cnt']].sum()
domestic_intl = domestic_intl.loc[df['Customer_id'].unique()]

# Sort by total transactions
domestic_intl['Total'] = domestic_intl['domestic_cnt'] + domestic_intl['International_cnt']
domestic_intl = domestic_intl.sort_values('Total', ascending=False)

# Create grouped bar chart
x = np.arange(len(domestic_intl))
width = 0.35

bars1 = ax.bar(x - width/2, domestic_intl['domestic_cnt'], width, label='Domestic', color='steelblue', alpha=0.8)
bars2 = ax.bar(x + width/2, domestic_intl['International_cnt'], width, label='International', color='coral', alpha=0.8)

# Customize the chart
ax.set_xlabel('Customer ID', fontsize=12, fontweight='bold')
ax.set_ylabel('Transaction Count', fontsize=12, fontweight='bold')
ax.set_title('Domestic vs International Transactions by Customer', fontsize=14, fontweight='bold')
ax.set_xticks(x)
ax.set_xticklabels(domestic_intl.index, rotation=45, ha='right')
ax.legend()
ax.grid(axis='y', alpha=0.3, linestyle='--')
ax.set_axisbelow(True)

# Add value labels on bars
for bars in [bars1, bars2]:
    for bar in bars:
        height = bar.get_height()
        if height > 0:
            ax.text(bar.get_x() + bar.get_width()/2., height,
                    f'{int(height)}',
                    ha='center', va='bottom', fontsize=8)

plt.tight_layout()
plt.show()

# Print breakdown
print("Domestic vs International Transaction Breakdown:")
for customer in domestic_intl.index:
    domestic = domestic_intl.loc[customer, 'domestic_cnt']
    international = domestic_intl.loc[customer, 'International_cnt']
    total = domestic + international
    domestic_pct = (domestic / total * 100) if total > 0 else 0
    intl_pct = (international / total * 100) if total > 0 else 0
    print(f"  {customer}: Domestic={int(domestic)} ({domestic_pct:.1f}%), International={int(international)} ({intl_pct:.1f}%), Total={int(total)}")

# Customer wise spend analyzer with pie charts
print("\n" + "="*50)
print("=== Customer Wise Spend Category Analyzer ===\n")

# Get spend categories for all customers
spend_categories = df.groupby('Customer_id')[['online_spend', 'instore_spend', 'travel_spend', 'fuel_spend', 'atm_withdrawal']].sum()

# Create pie charts for top 6 customers (by total spend)
top_customers = df.groupby('Customer_id')['total_spend'].sum().nlargest(6).index

# Create subplots for top customers
fig, axes = plt.subplots(2, 3, figsize=(16, 10))
axes = axes.flatten()

for idx, customer in enumerate(top_customers):
    ax = axes[idx]
    
    # Get spend data for this customer
    spend_data = spend_categories.loc[customer]
    spend_data = spend_data[spend_data > 0]  # Only show non-zero categories
    
    # Create pie chart
    colors = ['#FF9999', '#66B2FF', '#99FF99', '#FFD700', '#FF99CC']
    wedges, texts, autotexts = ax.pie(spend_data, labels=spend_data.index, autopct='%1.1f%%',
                                        colors=colors[:len(spend_data)], startangle=90)
    
    # Customize
    total_spend = spend_data.sum()
    ax.set_title(f'{customer} - Total: ${int(total_spend):,}', fontsize=11, fontweight='bold')
    
    # Make percentage text bold and white
    for autotext in autotexts:
        autotext.set_color('white')
        autotext.set_fontweight('bold')
        autotext.set_fontsize(8)
    
    # Adjust label size
    for text in texts:
        text.set_fontsize(8)

# Hide unused subplots
for idx in range(len(top_customers), len(axes)):
    axes[idx].axis('off')

plt.suptitle('Top 6 Customers - Spend Category Breakdown', fontsize=14, fontweight='bold', y=0.995)
plt.tight_layout()
plt.show()

# Print detailed spend breakdown
print("Customer Spend Category Breakdown (Top 10 Customers):\n")
top_10_customers = df.groupby('Customer_id')['total_spend'].sum().nlargest(10).index

for customer in top_10_customers:
    spend_data = spend_categories.loc[customer]
    total = spend_data.sum()
    print(f"\n{customer} - Total Spend: ${int(total):,}")
    print(f"  Online:      ${int(spend_data['online_spend']):>6,} ({spend_data['online_spend']/total*100:>5.1f}%)")
    print(f"  In-Store:    ${int(spend_data['instore_spend']):>6,} ({spend_data['instore_spend']/total*100:>5.1f}%)")
    print(f"  Travel:      ${int(spend_data['travel_spend']):>6,} ({spend_data['travel_spend']/total*100:>5.1f}%)")
    print(f"  Fuel:        ${int(spend_data['fuel_spend']):>6,} ({spend_data['fuel_spend']/total*100:>5.1f}%)")
    print(f"  ATM:         ${int(spend_data['atm_withdrawal']):>6,} ({spend_data['atm_withdrawal']/total*100:>5.1f}%)")

# Individual pie charts for each customer
print("\n" + "="*50)
print("=== Individual Customer Spend Category Pie Charts ===\n")

# Get all unique customers sorted by total spend
all_customers = df.groupby('Customer_id')['total_spend'].sum().sort_values(ascending=False).index

# Create pie charts for all customers - 3 per row
num_customers = len(all_customers)
num_cols = 3
num_rows = (num_customers + num_cols - 1) // num_cols

fig, axes = plt.subplots(num_rows, num_cols, figsize=(18, 5 * num_rows))
axes = axes.flatten()

category_colors = {'online_spend': '#FF9999', 'instore_spend': '#66B2FF', 
                   'travel_spend': '#99FF99', 'fuel_spend': '#FFD700', 'atm_withdrawal': '#FF99CC'}

for idx, customer in enumerate(all_customers):
    ax = axes[idx]
    
    # Get spend data for this customer
    spend_data = spend_categories.loc[customer]
    spend_data = spend_data[spend_data > 0]  # Only show non-zero categories
    
    # Prepare data for pie chart
    labels = ['Online', 'In-Store', 'Travel', 'Fuel', 'ATM']
    colors_list = ['#FF9999', '#66B2FF', '#99FF99', '#FFD700', '#FF99CC']
    
    # Create mapping of original column names to labels
    label_map = {
        'online_spend': 'Online',
        'instore_spend': 'In-Store',
        'travel_spend': 'Travel',
        'fuel_spend': 'Fuel',
        'atm_withdrawal': 'ATM'
    }
    
    # Filter and reorder
    filtered_labels = [label_map[col] for col in spend_data.index]
    filtered_colors = [category_colors[col] for col in spend_data.index]
    
    # Create pie chart
    wedges, texts, autotexts = ax.pie(spend_data.values, labels=filtered_labels, autopct='%1.1f%%',
                                        colors=filtered_colors, startangle=90)
    
    # Customize
    total_spend = spend_data.sum()
    rank = list(all_customers).index(customer) + 1
    ax.set_title(f'{customer} (Rank #{rank})\nTotal: ${int(total_spend):,}', 
                 fontsize=10, fontweight='bold')
    
    # Make percentage text bold and white
    for autotext in autotexts:
        autotext.set_color('white')
        autotext.set_fontweight('bold')
        autotext.set_fontsize(7)
    
    # Adjust label size
    for text in texts:
        text.set_fontsize(7)

# Hide unused subplots
for idx in range(num_customers, len(axes)):
    axes[idx].axis('off')

plt.suptitle('All Customers - Individual Spend Category Breakdown', fontsize=16, fontweight='bold', y=0.995)
plt.tight_layout()
plt.show()

print(f"Generated {num_customers} individual pie charts for all customers")

# Generate individual pie chart files for each customer
print("\n" + "="*50)
print("=== Generating Individual Customer Pie Chart Files ===\n")

# Create a subdirectory for customer pie charts
pie_charts_dir = os.path.join(script_dir, 'customer_pie_charts')
if not os.path.exists(pie_charts_dir):
    os.makedirs(pie_charts_dir)
    print(f"Created directory: {pie_charts_dir}")

# Generate individual pie chart for each customer
for customer in all_customers:
    fig, ax = plt.subplots(figsize=(10, 8))
    
    # Get spend data for this customer
    spend_data = spend_categories.loc[customer]
    spend_data = spend_data[spend_data > 0]  # Only show non-zero categories
    
    # Prepare data
    labels = ['Online', 'In-Store', 'Travel', 'Fuel', 'ATM']
    label_map = {
        'online_spend': 'Online',
        'instore_spend': 'In-Store',
        'travel_spend': 'Travel',
        'fuel_spend': 'Fuel',
        'atm_withdrawal': 'ATM'
    }
    
    # Filter and reorder
    filtered_labels = [label_map[col] for col in spend_data.index]
    filtered_colors = [category_colors[col] for col in spend_data.index]
    
    # Create pie chart
    wedges, texts, autotexts = ax.pie(spend_data.values, labels=filtered_labels, autopct='%1.2f%%',
                                        colors=filtered_colors, startangle=90, textprops={'fontsize': 11})
    
    # Get total spend and rank
    total_spend = spend_data.sum()
    rank = list(all_customers).index(customer) + 1
    
    # Customize title and labels
    ax.set_title(f'Customer {customer} - Spend Category Breakdown\nTotal Spend: ${int(total_spend):,} (Rank #{rank})',
                 fontsize=14, fontweight='bold', pad=20)
    
    # Make percentage text bold and white
    for autotext in autotexts:
        autotext.set_color('white')
        autotext.set_fontweight('bold')
        autotext.set_fontsize(10)
    
    # Adjust label size
    for text in texts:
        text.set_fontsize(11)
        text.set_fontweight('bold')
    
    # Add legend with amounts
    legend_labels = [f'{label}: ${int(spend_data.iloc[i]):,}' for i, label in enumerate(filtered_labels)]
    ax.legend(legend_labels, loc='upper left', bbox_to_anchor=(1, 1), fontsize=10)
    
    # Save figure
    filename = f'{customer}_spend_breakdown.png'
    filepath = os.path.join(pie_charts_dir, filename)
    plt.tight_layout()
    plt.savefig(filepath, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"[OK] Saved: {filename}")

print(f"\n[COMPLETE] All {len(all_customers)} pie charts saved to: {pie_charts_dir}")

# Summary table
print("\nSummary Table:")
summary = df.groupby('Customer_id').agg({
    'total_spend': ['sum', 'mean', 'max', 'min'],
    'txn_count': 'sum',
    'avg_txn_amount': 'mean'
}).round(2)
summary.columns = ['Total Spend', 'Avg Monthly Spend', 'Peak Spend', 'Min Spend', 'Total Transactions', 'Avg Transaction Amount']
print(summary)
