package com.verinite.bank.repository;

import com.verinite.bank.entity.BankEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BankRepo extends JpaRepository<BankEntity, Long> {
}
