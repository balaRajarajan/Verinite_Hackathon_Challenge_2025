package com.verinite.bank.dto;

import lombok.Data;

@Data
public class BankDto {

    private String mobile;
    private String email;
    private String pan;
    private String aadhaar;

    private String fullName;
    private String dob;
    private String gender;
    private String fatherName;
    private String maritalStatus;
    private String occupation;
    private Double annualIncome;
    private String nationality;

    private String status;

}
