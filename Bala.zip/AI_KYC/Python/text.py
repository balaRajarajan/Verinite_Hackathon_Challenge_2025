import cv2
import pytesseract
import numpy as np
import re

pytesseract.pytesseract.tesseract_cmd = r"C:\Users\V00680\AppData\Local\Programs\Tesseract-OCR\tesseract.exe"

def extract_aadhaar_data(image_path):
    img = cv2.imread(image_path)

    if img is None:
        return {"error": "Image not loaded"}

    # Rotation
    try:
        osd = pytesseract.image_to_osd(img)
        angle = int(re.search(r"Rotate: (\d+)", osd).group(1))
        if angle != 0:
            (h, w) = img.shape[:2]
            center = (w // 2, h // 2)
            M = cv2.getRotationMatrix2D(center, -angle, 1.0)
            img = cv2.warpAffine(img, M, (w, h))
    except:
        pass

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()

    blur_threshold = 60
    is_blurry = laplacian_var < blur_threshold

    gray = cv2.convertScaleAbs(gray, alpha=1.5, beta=20)

    data = pytesseract.image_to_data(
        gray,
        output_type=pytesseract.Output.DICT,
        config="--oem 3 --psm 6"
    )

    confidences = [int(conf) for conf in data["conf"] if conf != '-1']
    ocr_confidence = sum(confidences) / len(confidences) if confidences else 0

    text = pytesseract.image_to_string(
        gray,
        config="--oem 3 --psm 6"
    )

    lines = [line.strip() for line in text.split("\n") if line.strip()]

    aadhaar_number = None
    name = None
    dob = None
    gender = None

    aadhaar_match = re.search(r"\b\d{4}\s?\d{4}\s?\d{4}\b", text)
    if aadhaar_match:
        aadhaar_number = aadhaar_match.group()

    dob_match = re.search(r"\d{2}/\d{2}/\d{4}", text)
    if dob_match:
        dob = dob_match.group()

    if "Female" in text:
        gender = "Female"
    elif "Male" in text:
        gender = "Male"

    for i, line in enumerate(lines):
        if dob and dob in line:
            if i > 0:
                name = re.sub(r"[^A-Za-z ]", "", lines[i - 1]).strip()
            break

    return {
        "aadhaar_number": aadhaar_number,
        "name": name,
        "dob": dob,
        "gender": gender,
        "ocr_confidence_score": float(round(ocr_confidence, 2)),
        "is_blurry": bool(is_blurry),
        "blur_score": float(round(laplacian_var, 2))
    }
