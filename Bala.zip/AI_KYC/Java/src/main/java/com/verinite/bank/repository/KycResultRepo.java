package com.verinite.bank.repository;

import com.verinite.bank.entity.KycResultEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KycResultRepo extends JpaRepository<KycResultEntity, Long> {
}
