import React from "react";
import "./Home.css";
import { useNavigate } from "react-router-dom";


const Home = () => {
  const navigate = useNavigate();

  return (
    <div className="home">

      <header className="header">
        <div className="logo">VERINITE BANK</div>

        <nav className="nav">
          <a>Accounts</a>
          <a>Deposits</a>
          <a>Loans</a>
          <a>Cards</a>
          <a>Insurance</a>
          <button className="login-btn">Login</button>
        </nav>
      </header>

      <section className="hero">
        <div className="hero-content">
          <h1>Building a world class bank in India</h1>
          <p>
            Guided by ethics, powered by technology and a force for social good
          </p>
          <button className="cta-btn">Know more about the bank</button>
        </div>
      </section>

      <div className="tabs">
        <div className="tab active">Popular</div>
        <div className="tab">Accounts</div>
        <div className="tab">Deposits</div>
        <div className="tab">Credit Cards</div>
        <div className="tab">Loans</div>
        <div className="tab">Insurance</div>
      </div>

      <section className="cards">
        <div className="card red">
          <h3>Savings Account</h3>
          <p>Get Monthly Interest Payouts</p>
          <button onClick={() => navigate("/account-opening")}>
            Open Account
          </button>

        </div>

        <div className="card blue">
          <h3>Personal Loan</h3>
          <p>Foreclose anytime with ZERO charges</p>
          <button>Apply Now</button>
        </div>

        <div className="card purple">
          <h3>Credit Cards</h3>
          <p>Up to 10X never-expiring Reward Points</p>
          <button>Apply Now</button>
        </div>
      </section>

    </div>
  );
};

export default Home;
