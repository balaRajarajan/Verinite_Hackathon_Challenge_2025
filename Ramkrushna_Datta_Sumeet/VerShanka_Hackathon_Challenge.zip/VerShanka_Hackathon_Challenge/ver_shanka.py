import os
from openai import OpenAI
from pypdf import PdfReader
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from fastapi.templating import Jinja2Templates
import uvicorn

# ---------------- CONFIG ----------------
OPENROUTER_API_KEY = "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"
PDF_PATH = "./pdfs/env_science.pdf"
MODEL = "meta-llama/llama-3.3-70b-instruct"
# ----------------------------------------


# -------- OPENROUTER CLIENT --------
client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=OPENROUTER_API_KEY,
    default_headers={
        "HTTP-Referer": "http://localhost",
        "X-Title": "PDF-QA-Embedded",
    },
)


# -------- PDF UTILS --------
def read_pdf(path):
    reader = PdfReader(path)
    text = ""
    for page in reader.pages:
        page_text = page.extract_text()
        if page_text:
            text += page_text + "\n"
    return text


def chunk_text(text, chunk_size=1500, overlap=200):
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunks.append(text[start:end])
        start = end - overlap
    return chunks


# -------- CORE LOGIC --------
def ask_pdf(question, pdf_text):
    chunks = chunk_text(pdf_text)

    input_blocks = [
        {
            "role": "system",
            "content": "Answer questions using the provided document context."
        }
    ]

    for chunk in chunks[:3]:
        input_blocks.append({
            "role": "user",
            "content": f"Document content:\n{chunk}"
        })

    input_blocks.append({
        "role": "user",
        "content": question
    })

    response = client.responses.create(
        model=MODEL,
        input=input_blocks,
    )

    return response.output_text


# -------- LOAD PDF ONCE --------
PDF_TEXT = read_pdf(PDF_PATH)


# -------- FASTAPI SERVER --------
app = FastAPI(title="Embedded PDF QA API")
templates = Jinja2Templates(directory="templates")

class AskRequest(BaseModel):
    question: str

class AskResponse(BaseModel):
    answer: str

@app.post("/ask", response_model=AskResponse)
def ask(req: AskRequest):
    answer = ask_pdf(req.question, PDF_TEXT)
    return {"answer": answer}

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


# -------- ENTRY POINT --------
if __name__ == "__main__":
    mode = input("Type 'api' to start server or 'cli' for terminal mode: ").strip().lower()

    if mode == "cli":
        question = input("Ask a question about the PDF: ")
        answer = ask_pdf(question, PDF_TEXT)
        print("\n--- Answer ---\n")
        print(answer)

    else:
        uvicorn.run(
            app,
            host="127.0.0.1",
            port=8088
        )

	
	
	