import React, { useEffect, useRef, useState } from "react";
import "./FaceAadhaarKYC.css";

const FLASK_API = "http://localhost:8010/detect";
const FLASK_RESET = "http://localhost:8010/reset";
const JAVA_SAVE_API = "http://localhost:8999/api/bank/save-kyc";

const FRAME_INTERVAL = 800;

export default function FaceAadhaarKYC() {

    const videoRef = useRef(null);
    const overlayRef = useRef(null);
    const captureRef = useRef(null);

    const streamRef = useRef(null);
    const timerRef = useRef(null);
    const busyRef = useRef(false);

    const [status, setStatus] = useState("Waiting...");
    const [statusType, setStatusType] = useState("info");
    const [popupVisible, setPopupVisible] = useState(false);
    const [currentStage, setCurrentStage] = useState("FACE");

    /* ================= RESET BACKEND ================= */
    const resetBackend = async () => {
        try {
            await fetch(FLASK_RESET, { method: "POST" });
            setCurrentStage("FACE");
        } catch (err) {
            console.error("Reset error:", err);
        }
    };

    /* ================= START CAMERA ================= */
    const startCamera = async () => {
        if (streamRef.current) return;

        try {
            const applicationId = localStorage.getItem("applicationId");

            if (!applicationId) {
                alert("Application ID missing");
                return;
            }

            // 🔥 Reset Flask
            await resetBackend();

            // 🔥 Start Camera
            const stream = await navigator.mediaDevices.getUserMedia({ video: true });
            streamRef.current = stream;
            videoRef.current.srcObject = stream;

            setStatus("Camera started");
            setStatusType("info");

            timerRef.current = setInterval(sendFrame, FRAME_INTERVAL);

        } catch (err) {
            console.error(err);
            alert("Failed to start camera");
        }
    };

    /* ================= STOP CAMERA ================= */
    const stopCamera = () => {
        if (!streamRef.current) return;

        streamRef.current.getTracks().forEach(track => track.stop());
        streamRef.current = null;

        clearInterval(timerRef.current);

        const ctx = overlayRef.current.getContext("2d");
        ctx.clearRect(0, 0, overlayRef.current.width, overlayRef.current.height);

        setStatus("Camera stopped");
        setStatusType("info");
    };

    /* ================= SEND FRAME ================= */
    const sendFrame = async () => {

        const video = videoRef.current;
        const capture = captureRef.current;
        const overlay = overlayRef.current;

        if (!streamRef.current || busyRef.current || !video.videoWidth) return;
        busyRef.current = true;

        capture.width = video.videoWidth;
        capture.height = video.videoHeight;
        overlay.width = video.videoWidth;
        overlay.height = video.videoHeight;

        const ctx = capture.getContext("2d");
        const octx = overlay.getContext("2d");

        ctx.drawImage(video, 0, 0);

        const blob = await new Promise(resolve =>
            capture.toBlob(resolve, "image/jpeg", 0.9)
        );

        if (!blob) {
            busyRef.current = false;
            return;
        }

        const applicationId = localStorage.getItem("applicationId");

        const fd = new FormData();
        fd.append("file", blob);
        fd.append("user_id", Number(applicationId));  // 🔥 ADD THIS

        try {
            const res = await fetch(FLASK_API, {
                method: "POST",
                body: fd
            });

            const data = await res.json();

            console.log("BACKEND:", data);

            await handleResponse(data, octx);

        } catch (err) {
            console.error("Frame send error:", err);
        }

        busyRef.current = false;
    };

    /* ================= HANDLE RESPONSE ================= */
    const handleResponse = async (data, ctx) => {

        if (!ctx) return;

        ctx.clearRect(0, 0, overlayRef.current.width, overlayRef.current.height);

        // 🔥 Sync stage
        if (data.stage) {
            setCurrentStage(data.stage);
        }

        console.log("STAGE:", data.stage);
        console.log("STATUS:", data.status);

        /* ===== FACE ===== */
        if (data.stage === "FACE") {
            setPopupVisible(false);
            setStatus(data.status || "Detecting face...");
            setStatusType(
                data.status === "Unknown person" ? "error" : "info"
            );
            return;
        }

        /* ===== CARD ===== */
        if (data.stage === "CARD") {

            setPopupVisible(true);

            // 🔥 Draw simple center guide box (UI only)
            const w = overlayRef.current.width * 0.6;
            const h = w / 1.6;

            const x = (overlayRef.current.width - w) / 2;
            const y = (overlayRef.current.height - h) / 2;

            ctx.strokeStyle = "red";
            ctx.lineWidth = 3;
            ctx.strokeRect(x, y, w, h);

            setStatus(data.status || "Show Aadhaar clearly");
            setStatusType("info");

            return;
        }

        /* ===== DONE ===== */
        if (data.stage === "DONE") {

            setPopupVisible(false);
            stopCamera();

            setStatus("KYC Completed 🎉");
            setStatusType("success");

            try {
                const applicationId = localStorage.getItem("applicationId");

                await fetch(`${JAVA_SAVE_API}/${applicationId}`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(data.data)
                });

                alert("KYC saved successfully ✅");

            } catch (err) {
                console.error("Java save error:", err);
                alert("Failed to save KYC");
            }
        }
    };

    useEffect(() => {
        return () => stopCamera();
    }, []);

    return (
        <div className="kyc-container">

            <h2>Verinite KYC Process</h2>

            <div className="video-wrapper">
                <video ref={videoRef} autoPlay muted playsInline />
                <canvas ref={overlayRef} className="overlay" />
            </div>

            <canvas ref={captureRef} style={{ display: "none" }} />

            <div className="controls">
                <button className="start-btn" onClick={startCamera}>
                    Start Camera
                </button>

                <button className="stop-btn" onClick={stopCamera}>
                    Stop Camera
                </button>
            </div>

            {popupVisible && (
                <div className="popup">
                    📄 Please show your Aadhaar card
                </div>
            )}

            <div className={`status ${statusType}`}>
                {status}
            </div>

        </div>
    );
}