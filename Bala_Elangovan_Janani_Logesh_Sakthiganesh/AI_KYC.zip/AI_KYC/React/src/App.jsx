import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import AccountOpening from "./pages/AccountOpening";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/account-opening" element={<AccountOpening />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
